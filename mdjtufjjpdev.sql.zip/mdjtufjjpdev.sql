-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 05, 2012 at 08:54 AM
-- Server version: 5.5.9
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mdjtufjjpdev`
--

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_CATEGORIE`
--

CREATE TABLE IF NOT EXISTS `MDJT_CATEGORIE` (
  `idCategorie` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomCategorie` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `descriptionCategorie` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`idCategorie`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `MDJT_CATEGORIE`
--

INSERT INTO `MDJT_CATEGORIE` VALUES(1, 'Classique', 'Jeux Classique');
INSERT INTO `MDJT_CATEGORIE` VALUES(2, 'Action', 'Jeux d''action');
INSERT INTO `MDJT_CATEGORIE` VALUES(3, 'Aventure', 'Jeux d''aventure');

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_CATEGORIE_JEU`
--

CREATE TABLE IF NOT EXISTS `MDJT_CATEGORIE_JEU` (
  `idCategorieJeu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idJeu` int(10) unsigned NOT NULL,
  `idCategorie` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idCategorieJeu`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `MDJT_CATEGORIE_JEU`
--

INSERT INTO `MDJT_CATEGORIE_JEU` VALUES(1, 1, 1);
INSERT INTO `MDJT_CATEGORIE_JEU` VALUES(2, 2, 2);
INSERT INTO `MDJT_CATEGORIE_JEU` VALUES(3, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_EMPRUNT`
--

CREATE TABLE IF NOT EXISTS `MDJT_EMPRUNT` (
  `idEmprunt` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dateEmprunt` date NOT NULL,
  `dateRetourSouhaite` date NOT NULL,
  `dateRetourReel` date DEFAULT NULL,
  `idUtilisateur` int(10) unsigned NOT NULL,
  `idExemplaire` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idEmprunt`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `MDJT_EMPRUNT`
--

INSERT INTO `MDJT_EMPRUNT` VALUES(1, '2012-04-04', '2012-04-12', '2012-04-12', 1, 1);
INSERT INTO `MDJT_EMPRUNT` VALUES(2, '2012-04-12', '2012-04-18', '2012-04-20', 2, 2);
INSERT INTO `MDJT_EMPRUNT` VALUES(3, '2012-04-16', '2012-04-26', '2012-04-25', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_ETAT_EXEMPLAIRE`
--

CREATE TABLE IF NOT EXISTS `MDJT_ETAT_EXEMPLAIRE` (
  `idEtatExemplaire` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomEtat` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idEtatExemplaire`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `MDJT_ETAT_EXEMPLAIRE`
--

INSERT INTO `MDJT_ETAT_EXEMPLAIRE` VALUES(1, 'Disponible');
INSERT INTO `MDJT_ETAT_EXEMPLAIRE` VALUES(2, 'Indisponible');

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_EXEMPLAIRE`
--

CREATE TABLE IF NOT EXISTS `MDJT_EXEMPLAIRE` (
  `idExemplaire` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'idexemplaire = codeBarre',
  `descriptionExemplaire` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prixMJDT` decimal(8,0) NOT NULL,
  `dateAchat` date NOT NULL,
  `dateFinVie` date DEFAULT NULL,
  `idVersion` int(10) unsigned NOT NULL,
  `idEtatExemplaire` int(10) unsigned NOT NULL,
  `idLieuReel` int(10) unsigned NOT NULL,
  `idLieuTempo` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`idExemplaire`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `MDJT_EXEMPLAIRE`
--

INSERT INTO `MDJT_EXEMPLAIRE` VALUES(1, 'Puck Man', 50, '2012-04-03', '2014-04-01', 1, 1, 37, 37);
INSERT INTO `MDJT_EXEMPLAIRE` VALUES(2, 'Stealth Hunter 2', 100, '2012-02-14', '2015-04-14', 2, 2, 75, 37);
INSERT INTO `MDJT_EXEMPLAIRE` VALUES(3, 'Harry Quantum', 120, '2012-01-01', '2016-04-10', 3, 3, 45, 37);

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_EXTENSION`
--

CREATE TABLE IF NOT EXISTS `MDJT_EXTENSION` (
  `idExtension` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nature` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idVersionBase` int(10) unsigned NOT NULL,
  `idVersionExtension` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idExtension`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `MDJT_EXTENSION`
--


-- --------------------------------------------------------

--
-- Table structure for table `MDJT_FAIRE_PARTIE_KIT`
--

CREATE TABLE IF NOT EXISTS `MDJT_FAIRE_PARTIE_KIT` (
  `idFairePartieKit` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idExemplaire` int(10) unsigned NOT NULL,
  `idKitJeu` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idFairePartieKit`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `MDJT_FAIRE_PARTIE_KIT`
--


-- --------------------------------------------------------

--
-- Table structure for table `MDJT_INVENTAIRE`
--

CREATE TABLE IF NOT EXISTS `MDJT_INVENTAIRE` (
  `idInventaire` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dateInventaire` date NOT NULL,
  `commentaireInventaire` text COLLATE utf8_unicode_ci,
  `idUtilisateurs` int(10) unsigned NOT NULL,
  `idExemplaire` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idInventaire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `MDJT_INVENTAIRE`
--


-- --------------------------------------------------------

--
-- Table structure for table `MDJT_JEUX`
--

CREATE TABLE IF NOT EXISTS `MDJT_JEUX` (
  `idJeu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descriptionJeu` text COLLATE utf8_unicode_ci,
  `auteur` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idPays` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`idJeu`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `MDJT_JEUX`
--

INSERT INTO `MDJT_JEUX` VALUES(1, 'Puck-Man ou Crock-Man', 'Toto', 81);
INSERT INTO `MDJT_JEUX` VALUES(2, 'Stealth Hunter 2', 'Tutu', 86);
INSERT INTO `MDJT_JEUX` VALUES(3, 'Harry Quantum', 'Titi', 33);

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_KIT_JEU`
--

CREATE TABLE IF NOT EXISTS `MDJT_KIT_JEU` (
  `idKitJeu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomKit` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `descriptionKit` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idKitJeu`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `MDJT_KIT_JEU`
--


-- --------------------------------------------------------

--
-- Table structure for table `MDJT_LANGUE`
--

CREATE TABLE IF NOT EXISTS `MDJT_LANGUE` (
  `idLangue` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomLangue` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idLangue`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `MDJT_LANGUE`
--

INSERT INTO `MDJT_LANGUE` VALUES(1, 'English');
INSERT INTO `MDJT_LANGUE` VALUES(2, '中文');
INSERT INTO `MDJT_LANGUE` VALUES(3, 'Français');

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_LANGUE_REGLE`
--

CREATE TABLE IF NOT EXISTS `MDJT_LANGUE_REGLE` (
  `idLangueRegle` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idExemplaire` int(10) unsigned NOT NULL,
  `idLangue` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idLangueRegle`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `MDJT_LANGUE_REGLE`
--

INSERT INTO `MDJT_LANGUE_REGLE` VALUES(1, 1, 1);
INSERT INTO `MDJT_LANGUE_REGLE` VALUES(2, 2, 2);
INSERT INTO `MDJT_LANGUE_REGLE` VALUES(3, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_LIEU`
--

CREATE TABLE IF NOT EXISTS `MDJT_LIEU` (
  `idLieu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomLieu` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idLieu`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=76 ;

--
-- Dumping data for table `MDJT_LIEU`
--

INSERT INTO `MDJT_LIEU` VALUES(37, 'Tours');
INSERT INTO `MDJT_LIEU` VALUES(75, 'Paris');
INSERT INTO `MDJT_LIEU` VALUES(45, 'Orléan');

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_NB_JOUEUR`
--

CREATE TABLE IF NOT EXISTS `MDJT_NB_JOUEUR` (
  `idNbJoueur` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `nbJoueur` int(4) unsigned NOT NULL,
  PRIMARY KEY (`idNbJoueur`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `MDJT_NB_JOUEUR`
--

INSERT INTO `MDJT_NB_JOUEUR` VALUES(1, 2);
INSERT INTO `MDJT_NB_JOUEUR` VALUES(2, 3);
INSERT INTO `MDJT_NB_JOUEUR` VALUES(3, 4);
INSERT INTO `MDJT_NB_JOUEUR` VALUES(4, 5);
INSERT INTO `MDJT_NB_JOUEUR` VALUES(5, 6);
INSERT INTO `MDJT_NB_JOUEUR` VALUES(6, 7);
INSERT INTO `MDJT_NB_JOUEUR` VALUES(7, 8);

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_NB_JOUEUR_VERSION_JEU`
--

CREATE TABLE IF NOT EXISTS `MDJT_NB_JOUEUR_VERSION_JEU` (
  `idNbJoueurJeu` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `idNbJoueur` int(10) unsigned NOT NULL,
  `idVersion` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idNbJoueurJeu`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `MDJT_NB_JOUEUR_VERSION_JEU`
--

INSERT INTO `MDJT_NB_JOUEUR_VERSION_JEU` VALUES(1, 3, 1);
INSERT INTO `MDJT_NB_JOUEUR_VERSION_JEU` VALUES(2, 4, 2);
INSERT INTO `MDJT_NB_JOUEUR_VERSION_JEU` VALUES(3, 5, 3);

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_NOM_JEU`
--

CREATE TABLE IF NOT EXISTS `MDJT_NOM_JEU` (
  `idNomJeu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomJeu` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `idLangue` int(10) unsigned NOT NULL,
  `idJeu` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idNomJeu`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `MDJT_NOM_JEU`
--

INSERT INTO `MDJT_NOM_JEU` VALUES(1, 'Puck Man', 1, 1);
INSERT INTO `MDJT_NOM_JEU` VALUES(2, 'Stealth Hunter 2', 2, 2);
INSERT INTO `MDJT_NOM_JEU` VALUES(3, 'Harry Quantum', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_NOTE_VERSION`
--

CREATE TABLE IF NOT EXISTS `MDJT_NOTE_VERSION` (
  `idNoteVersion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `noteVersion` int(10) unsigned NOT NULL,
  `commentaireNoteVersion` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idUtilisateurs` int(10) unsigned NOT NULL,
  `idVersion` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idNoteVersion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `MDJT_NOTE_VERSION`
--


-- --------------------------------------------------------

--
-- Table structure for table `MDJT_PAYS`
--

CREATE TABLE IF NOT EXISTS `MDJT_PAYS` (
  `idPays` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomPays` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idPays`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=87 ;

--
-- Dumping data for table `MDJT_PAYS`
--

INSERT INTO `MDJT_PAYS` VALUES(33, 'France');
INSERT INTO `MDJT_PAYS` VALUES(86, 'China');
INSERT INTO `MDJT_PAYS` VALUES(81, 'Japan');
INSERT INTO `MDJT_PAYS` VALUES(1, 'American');
INSERT INTO `MDJT_PAYS` VALUES(44, 'England');
INSERT INTO `MDJT_PAYS` VALUES(39, 'Italy');

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_PHOTO`
--

CREATE TABLE IF NOT EXISTS `MDJT_PHOTO` (
  `idPhoto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomPhoto` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `texteAlternatif` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idPhoto`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `MDJT_PHOTO`
--


-- --------------------------------------------------------

--
-- Table structure for table `MDJT_PHOTO_VERSION`
--

CREATE TABLE IF NOT EXISTS `MDJT_PHOTO_VERSION` (
  `idPhotoVersion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idPhoto` int(10) unsigned NOT NULL,
  `idVersion` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idPhotoVersion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `MDJT_PHOTO_VERSION`
--


-- --------------------------------------------------------

--
-- Table structure for table `MDJT_RESERVATION`
--

CREATE TABLE IF NOT EXISTS `MDJT_RESERVATION` (
  `idReversation` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dateSouhaiteEmprunt` date NOT NULL,
  `idUtilisateur` int(10) unsigned NOT NULL,
  `idExemplaire` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idReversation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `MDJT_RESERVATION`
--

INSERT INTO `MDJT_RESERVATION` VALUES(1, '2012-04-10', 1, 1);
INSERT INTO `MDJT_RESERVATION` VALUES(2, '2012-04-12', 2, 2);
INSERT INTO `MDJT_RESERVATION` VALUES(3, '2012-04-16', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `MDJT_SUGGESTION`
--

CREATE TABLE IF NOT EXISTS `MDJT_SUGGESTION` (
  `idSuggestion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `commentaireSugeestion` text COLLATE utf8_unicode_ci,
  `etatSuggestion` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `idUtilisateur` int(10) unsigned NOT NULL,
  `idJeux` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idSuggestion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `MDJT_SUGGESTION`
--


-- --------------------------------------------------------

--
-- Table structure for table `MDJT_VERSION`
--

CREATE TABLE IF NOT EXISTS `MDJT_VERSION` (
  `idVersion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomVersion` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `descriptionVersion` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ageMinimum` mediumint(8) unsigned DEFAULT NULL,
  `nbJoueurRecommande` mediumint(8) unsigned DEFAULT NULL,
  `dureePartie` timestamp NULL DEFAULT NULL,
  `prixAchat` decimal(8,0) unsigned NOT NULL,
  `anneeSortie` year(4) DEFAULT NULL,
  `illustrateur` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `distributeur` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `editeur` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `idJeu` int(10) unsigned NOT NULL,
  `idLangue` int(10) unsigned DEFAULT NULL,
  `nbJoueur` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idVersion`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `MDJT_VERSION`
--

INSERT INTO `MDJT_VERSION` VALUES(1, '1.0', 'C''est la version originale', 18, 3, '0000-00-00 00:00:00', 50, 1999, 'Toto', 'Toto', 'Toto', 1, 1, NULL);
INSERT INTO `MDJT_VERSION` VALUES(2, '1.0', 'C''est la version originale', 12, 6, '0000-00-00 00:00:00', 100, 2006, 'Tutu', 'Tutu', 'Tutu', 2, 2, NULL);
INSERT INTO `MDJT_VERSION` VALUES(3, '1.0', 'C''est la version originale', 18, 8, '0000-00-00 00:00:00', 120, 2012, 'Titi', 'Titi', 'Titi', 3, 3, NULL);
